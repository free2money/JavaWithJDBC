package management;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		mainMenu();
	}

	private static void mainMenu() throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		int num = 0;
		// �߸��� �Է��� ���� �� ���ܸ� �߻���Ű�� �ʱ�����
		// �ݺ����� ����Ͽ� �Է� ������ ������.
		do {
			System.out.println("-----------------");
			System.out.println("    ���� �޴�");
			System.out.println("-----------------\n");
			System.out.println("1. ȸ�� ����");
			System.out.println("2. �Խñ� ����");
			System.out.println("3. ����\n");
			System.out.print("> ");
			num = sc.nextInt();
			switch (num) {
			case 1:
				printMemberList();
				break;
			case 2:
				printNoticeList();
				break;
			case 3:
				System.out.println("����� �����մϴ�.");
				System.exit(0);
				break;
			default:
				System.out.println("�߸��� �Է��Դϴ�.");
				mainMenu();
				break;
			}
		} while (num != 3);
		sc.close();
	}

	private static void printMemberList() throws ClassNotFoundException, SQLException {
		System.out.println("ȸ�� ����");
	}

	private static void printNoticeList() throws SQLException, ClassNotFoundException {
		String url = "jdbc:oracle:thin:@192.168.0.3:1521/xepdb1";
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection(url, "ACORN", "newlec");
		Statement st = con.createStatement();
		String sql = "select id, title, hit, writer_id, regdate from notice order by regdate desc";
		ResultSet rs = st.executeQuery(sql);

		System.out.println("<�Խñ� ���>\n");

		while (rs.next()) {
//			int id = rs.getInt("id");
//			String title = rs.getString("title");
//			int hit = rs.getInt("hit");
//			String wid = rs.getString("writer_id");
//			String regdate = rs.getString("regdate");
			Notice n = new Notice();
			n.setId(rs.getInt("id"));
			n.setTitle(rs.getString("title"));
			n.setWriter_id(rs.getString("writer_id"));
			n.setRegdate(rs.getString("regdate"));
			n.setHit(rs.getInt("hit"));
			System.out.println(n.getId() + ".\t" + n.getTitle() + "(" + n.getHit() + ")[" + n.getWriter_id() + "] / "
					+ n.getRegdate());
		}
		rs.close();
		st.close();
		con.close();

		System.out.println("--------------------------------------------------------------------");
		System.out.print("1. ��ȸ\t2. �˻�\t3. ���\t4. �����޴��� > ");
		Scanner sc = new Scanner(System.in);
		switch (sc.nextInt()) {
		case 1:
			System.out.print("�ڵ� > ");
			int num = sc.nextInt();
			printNotice(num); // �ϳ��� ���븸 ���
			break;
		case 2:
			System.out.println("�˻��մϴ�.");
			printNoticeList(); // ��ü ����� ���
//			listNotice(int page); // �˻��� ����� ���
			break;
		case 3:
			regNotice();
			break;
		case 4:
			mainMenu();
			break;
		default:
			System.out.println("�߸��� �Է��Դϴ�.");
			printNoticeList();
			break;
		}
	}

	private static void regNotice() {
		System.out.println("���ο� ���� ����մϴ�.");
	}

	private static void printNotice(int num) throws ClassNotFoundException, SQLException {
		String url = "jdbc:oracle:thin:@192.168.0.3:1521/xepdb1";
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection(url, "ACORN", "newlec");
		Statement st = con.createStatement();
		String sql = "select id, title, writer_id, regdate, hit, content from notice where id = "
				+ Integer.toString(num);
		ResultSet rs = st.executeQuery(sql);

		System.out.println("�����Խñ� ����\n");
		do {
			if (rs.next()) {
				int id = rs.getInt("id");
				String title = rs.getString("title");
				int hit = rs.getInt("hit");
				String wid = rs.getString("writer_id");
				String regdate = rs.getString("regdate");
				String str = rs.getString("content");

				System.out.println("��ȣ : " + id);
				System.out.println("���� : " + title);
				System.out.println("�ۼ��� : " + wid);
				System.out.println("�ۼ��� : " + regdate);
				System.out.println("��ȸ�� : " + hit);
				System.out.print("���� : ");
				System.out.println(str);
				System.out.println("---------------------------------------------------------------");
			} else {
				System.out.println("�߸��� ������ �Է��Ͽ����ϴ�.");
				printNoticeList();
			}
		} while (rs.next());
		rs.close();
		st.close();
		con.close();
		printCommentList(num);
	}

	private static void printCommentList(int num) throws SQLException, ClassNotFoundException {
		String url = "jdbc:oracle:thin:@192.168.0.3:1521/xepdb1";
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection(url, "ACORN", "newlec");
		Statement st = con.createStatement();
		System.out.println("��� ���");
		String sql = "select content, writer_id, regdate from	\"COMMENT\" where notice_id = " + Integer.toString(num);
		ResultSet rs = st.executeQuery(sql);

		while (rs.next()) {
			String wid = rs.getString("writer_id");
			String regdate = rs.getString("regdate");
			String str = rs.getString("content");
			System.out.println("�� " + str + "[" + wid + "] " + regdate);
		}
		rs.close();
		st.close();
		con.close();
		System.out.println("-------------------------------------------------------------------");
		System.out.print("1. ��۵��\t2. ���\t 3. ����\t4. ���� > ");
		Scanner sc = new Scanner(System.in);
		switch (sc.nextInt()) {
		case 1:
			regComment(num);
			break;
		case 2:
			printNoticeList();
			break;
		case 3:
			updateNotice(num);
			break;
		case 4:
			deleteNotice(num);
			break;
		default:
			System.out.println("�߸��� �Է��Դϴ�.");
			printNotice(num);
			break;
		}
	}

	private static void deleteNotice(int num) {
		System.out.println("���� �����մϴ�.");
	}

	private static void updateNotice(int num) {
		System.out.println("���� �����մϴ�.");
	}

	private static void regComment(int num) {
		System.out.println("���ο� ����� ����մϴ�.");

	}
}
