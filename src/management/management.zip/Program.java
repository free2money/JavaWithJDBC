package management;

import java.sql.SQLException;

public class Program {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		MainMenu.mainmenu();
	}
}
